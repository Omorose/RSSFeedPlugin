/** Automatically generated file. DO NOT MODIFY */
package se.miun.omorose.rssfeedplugin.cordova;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}